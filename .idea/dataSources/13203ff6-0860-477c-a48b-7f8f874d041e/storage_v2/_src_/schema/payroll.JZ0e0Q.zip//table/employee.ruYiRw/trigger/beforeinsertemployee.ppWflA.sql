create trigger beforeInsertEmployee
  before INSERT
  on employee
  for each row
  BEGIN
    DELETE FROM deletedemployee WHERE empno = NEW.empno;
  end;

