create procedure searchEmployee(IN searchIndex int)
  BEGIN
    SELECT * FROM employee WHERE empno = searchIndex;
  END;

