create procedure addEmployee(IN empNo int, IN empName varchar(100), IN dob date)
  BEGIN
    INSERT INTO employee values (empNo, empName, dob);
  END;

