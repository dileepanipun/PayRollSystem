create procedure searchLevel(IN newLvlID int)
  BEGIN
    SELECT * FROM level
    WHERE LvlID = newLvlID;
  END;

