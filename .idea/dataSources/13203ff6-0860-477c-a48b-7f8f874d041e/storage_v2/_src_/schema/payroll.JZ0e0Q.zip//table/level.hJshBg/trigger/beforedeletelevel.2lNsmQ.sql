create trigger beforeDeleteLevel
  after DELETE
  on level
  for each row
  BEGIN
    INSERT INTO deletedLevel VALUES (OLD.LvlID, OLD.levelName, OLD.medicalVal, OLD.basicSalary, USER());
  end;

