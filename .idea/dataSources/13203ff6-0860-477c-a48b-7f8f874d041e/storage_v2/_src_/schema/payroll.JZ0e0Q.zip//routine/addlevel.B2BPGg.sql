create procedure addLevel(IN lvlName varchar(100), IN medlVal decimal(10, 2), IN bSalary decimal(10, 2))
  BEGIN
    INSERT INTO level(levelName, medicalVal, basicSalary) values(lvlName, medlVal, bSalary) ;
  END;

