create procedure updateLevel(IN newLvlID int, IN lvlName varchar(15), IN medVal decimal(10, 2), IN bSal decimal(10, 2))
  BEGIN
    UPDATE level
    SET levelName = lvlName, medicalVal = medVal, basicSalary = bSal
    WHERE LvlID = newLvlID;
  END;

