create trigger afterDeleteEmployee
  after DELETE
  on employee
  for each row
  BEGIN
    INSERT INTO deletedemployee VALUES (OLD.empno, OLD.empName, OLD.DOB, user());
  end;

