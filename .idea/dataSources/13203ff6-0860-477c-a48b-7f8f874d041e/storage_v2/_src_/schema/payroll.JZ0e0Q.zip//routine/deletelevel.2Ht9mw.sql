create procedure deleteLevel(IN newLvlID int)
  BEGIN
    DELETE FROM level
    WHERE LvlID = newLvlID;
  END;

