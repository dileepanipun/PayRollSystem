create procedure updateEmployee(IN newEmpNo int, IN newEmpName varchar(100), IN newDob date)
  BEGIN
    UPDATE employee  SET empName = newEmpName , DOB = newDob WHERE empNo = newEmpNo;
  END;

