create procedure deleteEmployee(IN newEmpNo int)
  BEGIN
    DELETE FROM employee WHERE empno = newEmpNo;
  END;

