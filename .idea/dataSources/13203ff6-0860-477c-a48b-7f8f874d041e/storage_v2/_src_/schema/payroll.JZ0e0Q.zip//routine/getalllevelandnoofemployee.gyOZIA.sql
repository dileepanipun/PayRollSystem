create procedure getAllLevelAndNoOfEmployee()
  BEGIN
    SELECT
      *,
      (SELECT count(*)
       FROM employeelevel el
       WHERE l.LvlID = el.LvlID) as noOfEmp
    FROM level l;
  END;

