create trigger beforeInsertLevel
  before INSERT
  on level
  for each row
  BEGIN
    DELETE FROM deletedlevel  WHERE LvlID = NEW.LvlID;
  end;

