create procedure getAllLevel()
  BEGIN
    SELECT * FROM level;
  END;

